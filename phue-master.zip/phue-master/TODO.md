#phue TODO

 * Find a more elegant way to deal with transitiontime
 * Add a Group class
 * Cleanup the connect and register_app methods
 * ~~Replace prints with proper logging mechanism~~
 * ~~Read/Write config file from cwd if home is not writable~~
 * ~~Store IP in config file~~
 * ~~Add support for groups~~
 * ~~Make username passable as argument and config file optional (so it can run when no write access is present like on iphone)~~
 * ~~Rename Bulb to Light to conform to API~~ (done)
 * ~~Add the ability to get and set the bridge name~~ (done)
 * ~~Update Bulbs dictionary when lights are renamed~~ (done)
